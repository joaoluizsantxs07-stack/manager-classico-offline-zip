MANAGER CLASSICO OFFLINE - PROJETO ANDROID

Este projeto empacota o prototipo HTML em um aplicativo Android usando WebView.
O jogo roda offline e salva a carreira no armazenamento local do aplicativo.

GERAR O APK PELO GITHUB (SEM ANDROID STUDIO NO CELULAR)
1. Extraia o ZIP em uma pasta do computador.
2. Entre em https://github.com e crie uma conta, se ainda nao tiver.
3. Crie um repositorio novo, por exemplo: manager-classico-offline.
4. Envie TODOS os arquivos e pastas deste projeto para a raiz do repositorio
   (incluindo a pasta oculta .github).
5. Abra a aba Actions do repositorio.
6. Se aparecer uma solicitacao para habilitar Actions, habilite.
7. Selecione "Gerar APK - Manager Classico Offline" e toque em
   "Run workflow". Tambem compila automaticamente ao enviar commits para
   main ou master.
8. Quando terminar com sucesso (marca verde), abra a execucao e baixe o
   artefato "Manager-Classico-Offline-APK".
9. Extraia o ZIP baixado. Dentro dele estara app-debug.apk.
10. Envie o APK ao Moto G05 e instale. Se o Android pedir, permita instalar
    aplicativos desta fonte nas configuracoes.

COMPILACAO LOCAL (OPCIONAL)
- JDK 17
- Android SDK Platform 35
- Gradle 8.9
- Execute: gradle assembleDebug
- APK: app/build/outputs/apk/debug/app-debug.apk

OBSERVACOES
- Este e um APK de depuracao (debug), adequado para testes e instalacao manual.
- Nao e o OSM original, nao usa servidores da Gamebasics e usa clubes/jogadores
  ficticios no prototipo atual.
- Nao ha permissao de internet no manifesto: o app nao precisa de rede para jogar.
- O ZIP contem o codigo-fonte; ainda nao contem um APK compilado.
